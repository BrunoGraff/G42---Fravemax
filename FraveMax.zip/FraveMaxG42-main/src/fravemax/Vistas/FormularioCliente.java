
package fravemax.Vistas;

import fravemax.AccesoADatos.ClienteData;
import fravemax.Entidades.Cliente;
import java.util.Locale;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;



public class FormularioCliente extends javax.swing.JInternalFrame {
    
    //Declaracion instancia cliente para almacenamiento de datos de cliente.
    Cliente cl;
    //Instanciacion clase de servicio.
    ClienteData clData = new ClienteData();

    public FormularioCliente() {
        
        initComponents();
        limpiarCamposYBotones(); 
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jbSalir = new javax.swing.JButton();
        jbGuardarNuevoCliente = new javax.swing.JButton();
        jbEliminarCliente = new javax.swing.JButton();
        jbModificarCliente = new javax.swing.JButton();
        jbLimpiarCampos = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jbBuscarXDni = new javax.swing.JButton();
        jtfDniCliente = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jtfApellidoCliente = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jtfNombreCliente = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jtfDireccionCliente = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jtfTelefonoCliente = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 205, 183));

        jbSalir.setText("Salir");
        jbSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbSalirActionPerformed(evt);
            }
        });

        jbGuardarNuevoCliente.setText("Guardar");
        jbGuardarNuevoCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbGuardarNuevoClienteActionPerformed(evt);
            }
        });

        jbEliminarCliente.setText("Eliminar");

        jbModificarCliente.setText("Modificar");
        jbModificarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbModificarClienteActionPerformed(evt);
            }
        });

        jbLimpiarCampos.setText("Limpiar");
        jbLimpiarCampos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbLimpiarCamposActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(240, 189, 142));

        jLabel1.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        jLabel1.setText("DNI");

        jbBuscarXDni.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fravemax/Imagicon/Buscar.png"))); // NOI18N
        jbBuscarXDni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbBuscarXDniActionPerformed(evt);
            }
        });

        jtfDniCliente.setToolTipText("");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                .addComponent(jtfDniCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jbBuscarXDni, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jbBuscarXDni, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jtfDniCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1)))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(240, 189, 142));
        jPanel2.setPreferredSize(new java.awt.Dimension(422, 45));

        jLabel2.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        jLabel2.setText("Apellido");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(26, 26, 26)
                .addComponent(jtfApellidoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtfApellidoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(240, 189, 142));
        jPanel3.setPreferredSize(new java.awt.Dimension(0, 45));

        jLabel3.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        jLabel3.setText("Nombre");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(41, 41, 41)
                .addComponent(jtfNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtfNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(240, 189, 142));
        jPanel4.setPreferredSize(new java.awt.Dimension(0, 45));

        jLabel5.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        jLabel5.setText("Direccion");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jtfDireccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtfDireccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addContainerGap())
        );

        jPanel5.setBackground(new java.awt.Color(240, 189, 142));
        jPanel5.setPreferredSize(new java.awt.Dimension(0, 45));

        jLabel4.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        jLabel4.setText("Telefono");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(26, 26, 26)
                .addComponent(jtfTelefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtfTelefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jLabel6.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        jLabel6.setText("CLIENTES");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jbLimpiarCampos)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jbModificarCliente)
                        .addGap(18, 18, 18)
                        .addComponent(jbEliminarCliente)
                        .addGap(18, 18, 18)
                        .addComponent(jbGuardarNuevoCliente)
                        .addGap(22, 22, 22)
                        .addComponent(jbSalir))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(172, 172, 172)
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbGuardarNuevoCliente)
                    .addComponent(jbEliminarCliente)
                    .addComponent(jbModificarCliente)
                    .addComponent(jbLimpiarCampos)
                    .addComponent(jbSalir))
                .addGap(36, 36, 36))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbSalirActionPerformed
       
        //Se deja el objeto en condicion de ser eliminado al fin del prog.        
        cl = null;
        clData = null;
        dispose();
        
    }//GEN-LAST:event_jbSalirActionPerformed

    private void jbLimpiarCamposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbLimpiarCamposActionPerformed
        
        limpiarCamposYBotones();
        
    }//GEN-LAST:event_jbLimpiarCamposActionPerformed

    private void jbGuardarNuevoClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbGuardarNuevoClienteActionPerformed
        
        //Verificacion de campos.  
        if(comprobarCamposAlGuardOModif()){
            //Si la condicion resulta true, es que algo resulto en verdad mal.
            return;
            
        } else {
        
        //Instanciar Cliente Nuevo.
        cl = instanciarDesdeCampos();    
        
        //Envio de datos a BD.
        clData.agregarCliente(cl);
        limpiarCamposYBotones();
        }
    }//GEN-LAST:event_jbGuardarNuevoClienteActionPerformed

    private void jbModificarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbModificarClienteActionPerformed
        
        //Verificacion de campos.
        if(comprobarCamposAlGuardOModif()){
            //Si la condicion resulta true, es que algo resulto en verdad mal.
            return;
            
        } else {
        
        //Instanciar Cliente Modificado.
        cl = instanciarDesdeCampos();
        
        //Envio de modificaciones a BD.
        clData.modificarCliente(cl);
        
        //Limpieza de instancia cliente.
        cl = null;
        
        //Se inhabilitan otras dos operaciones.
        jbModificarCliente.setEnabled(false);//Solo se permite modificar luego de buscar.
        jbEliminarCliente.setEnabled(false);//Solo se permite eliminar luego de buscar.
        }
    }//GEN-LAST:event_jbModificarClienteActionPerformed

    private void jbBuscarXDniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbBuscarXDniActionPerformed

        //Verificacion de campos.
        if(comprobarCamposAlBuscar()){
            //Si la condicion resulta true, es que algo resulto en verdad mal.
            return;
            
        } else {
        
        //Obtener valor DNI para busqueda en BD.
        try{
        cl = clData.buscarClienteXDni((int) Long.parseLong(jtfDniCliente.getText()));
        
        //Mostrar Campos.
        
       
        jtfApellidoCliente.setText(cl.getApellido());
        jtfNombreCliente.setText(cl.getNombre());
        jtfDireccionCliente.setText(cl.getDomicilio());
        jtfTelefonoCliente.setText(cl.getTelefono());
        
                //Se habilitan otras dos operaciones.
        jbModificarCliente.setEnabled(true);//Solo se permite modificar luego de buscar.
        jbEliminarCliente.setEnabled(true);//Solo se permite eliminar luego de buscar.
        
        
        }catch (NullPointerException npe){
        JOptionPane.showMessageDialog(this, "No se ha encontrado el cliente");
        }


        }
    }//GEN-LAST:event_jbBuscarXDniActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JButton jbBuscarXDni;
    private javax.swing.JButton jbEliminarCliente;
    private javax.swing.JButton jbGuardarNuevoCliente;
    private javax.swing.JButton jbLimpiarCampos;
    private javax.swing.JButton jbModificarCliente;
    private javax.swing.JButton jbSalir;
    private javax.swing.JTextField jtfApellidoCliente;
    private javax.swing.JTextField jtfDireccionCliente;
    private javax.swing.JTextField jtfDniCliente;
    private javax.swing.JTextField jtfNombreCliente;
    private javax.swing.JTextField jtfTelefonoCliente;
    // End of variables declaration//GEN-END:variables
    
    private void limpiarCamposYBotones(){
        
        //Limpieza de botones.
        jbBuscarXDni.setEnabled(true);
        jbEliminarCliente.setEnabled(false);
        jbGuardarNuevoCliente.setEnabled(true);
        jbModificarCliente.setEnabled(false);
        
        //Limpieza de campos.
        jtfApellidoCliente.setText("");
        jtfNombreCliente.setText("");
        jtfDireccionCliente.setText("");
        jtfDniCliente.setText("");
        jtfTelefonoCliente.setText("");
        
    }
    
    private boolean verificarCamposVacios(){
        
        return (jtfApellidoCliente.getText().equals("") || jtfNombreCliente.getText().equals("") ||
                    jtfDniCliente.getText().equals("") || jtfDireccionCliente.getText().equals("") ||
                        jtfTelefonoCliente.getText().equals(""));  
        
    }
    
    //Esta funcion busca si hay un numero en un String que se supone no debe tener numeros.
    private boolean verificarSiHayNumeros(String cadena){
        
        for(int i=0; i<cadena.length(); i++){
            
            try{//Se intenta parsear cada caracter a numero.
                Integer.parseInt(cadena.charAt(i)+"");

                return true;

        }catch(NumberFormatException nfE){//Si no se puede parsear se produce la excepcion
            }                           //indicando que el caracter no es un numero.
        }     
        
        return false; 
        
    }
    
    //Esta funcion busca si hay un letras en un String que se supone no debe tener letras.
    private boolean verificarSiHayLetras(String cadena){
        
        try{
           long num = Long.parseLong(cadena);
        }catch(NumberFormatException nfE){
            return true;
        }
        
        return false;
        
    }
    
    private boolean excedeLongitudMax(String cadena, int dimMax){
       
        return cadena.length()>dimMax;
        
    }
    
    private boolean comprobarCamposAlGuardOModif(){
        
        if(excedeLongitudMax((jtfDniCliente.getText()+""), 11) || excedeLongitudMax(jtfApellidoCliente.getText(), 60) ||
                excedeLongitudMax(jtfNombreCliente.getText(), 60) || excedeLongitudMax(jtfDireccionCliente.getText(), 100) ||
                    excedeLongitudMax(jtfTelefonoCliente.getText(), 20)){
            JOptionPane.showMessageDialog(this, "...mmm, alguno de los campos excede la longitud permitida.");
            return true;
        }           
       
        if(verificarCamposVacios()){
            JOptionPane.showMessageDialog(this, "...mmm, ha dejado uno o mas campos vacios.");
            return true;
        }
        
        if(verificarSiHayNumeros(jtfApellidoCliente.getText()) || verificarSiHayNumeros(jtfNombreCliente.getText())){
            JOptionPane.showMessageDialog(this, "...mmm, parece que hay numeros, en los campos Nombre y/o Apellido.");
            return true;
        }
        
        if(verificarSiHayLetras(jtfDniCliente.getText()) || verificarSiHayLetras(jtfTelefonoCliente.getText())){
            JOptionPane.showMessageDialog(this, "...mmm, parece que hay letras o simbolos, en los campos DNI y/o Telefono.");
            return true;
        }
        
                if(comparar() != null){
           JOptionPane.showMessageDialog(this, "El DNI ingresado ya esta cargado como cliente.");
            return true; 
        }
        
        return false;
        
    }
    
    private boolean comprobarCamposAlBuscar(){
        
        if(!jtfApellidoCliente.getText().isEmpty() || !jtfNombreCliente.getText().isEmpty() ||
                !jtfDireccionCliente.getText().isEmpty() || !jtfTelefonoCliente.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "...recuerde que la busqueda de clientes es solo por dni.");
            //Este bloque solamente recuerda al usuario como hacer una busqueda de Cliente.
        }
            
        if(excedeLongitudMax((jtfDniCliente.getText()+""), 11)){
            JOptionPane.showMessageDialog(this, "...mmm, dni excede la longitud permitida.");
            return true;
        }
        
        if(jtfDniCliente.getText().equals("")){
            JOptionPane.showMessageDialog(this, "...mmm, ha dejado el campo dni vacio.");
            return true;
        }
        
        if(verificarSiHayLetras(jtfDniCliente.getText())){
           JOptionPane.showMessageDialog(this, "...mmm, el campo dni no lleva letras ni puntos y tampoco espacios, solo numeros.");
            return true; 
        }
        

        return false;
        
    }
    
    private Cliente instanciarDesdeCampos(){
        
        Cliente cli = new Cliente();
        
        try{
            cli.setIdCliente(cl.getIdCliente());
        }catch(NullPointerException npE){
            //En caso de que se esté intentando guardar por primera vez.
        }
        
        cli.setDni((int) Long.parseLong(jtfDniCliente.getText()));
        cli.setApellido(jtfApellidoCliente.getText().toLowerCase());
        cli.setNombre(jtfNombreCliente.getText().toLowerCase());
        cli.setDomicilio(jtfDireccionCliente.getText().toLowerCase());
        cli.setTelefono(jtfTelefonoCliente.getText().toLowerCase());
        
        return cli;
        
    }
    
        public Cliente comparar (){
    Cliente C = new Cliente();
    ClienteData Cd =new ClienteData();
    Cd.buscarClienteXDni((int)Long.parseLong(jtfDniCliente.getText()));
        return C;
    }
    
}
    

