
package fravemax;

import fravemax.AccesoADatos.ClienteData;
import fravemax.AccesoADatos.Conexion;
import fravemax.AccesoADatos.DetalleVentaData;
import fravemax.AccesoADatos.ProductoData;
import fravemax.AccesoADatos.VentaData;
import fravemax.Entidades.Cliente;
import fravemax.Entidades.DetalleVenta;
import fravemax.Entidades.Producto;
import fravemax.Entidades.Venta;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.Month;
import javax.swing.JOptionPane;


public class FraveMax {

    public static void main(String[] args) {
        // TODO code application logic here
        Connection con = Conexion.getConexion();
        Cliente cliente = new Cliente(42963963, "Juarez", "Marcos", "Huiz 456", "124578");
//        ClienteData cData=new ClienteData();
//        cData.agregarCliente(cliente);

//
//        Venta venta = new Venta(8, cliente, LocalDate.of(2023, Month.AUGUST, 25));
//        VentaData vData=new VentaData();
//        vData.registraVenta(venta);
//        System.out.println("Venta Nueva");

        Producto producto = new Producto(3, "Heladera", "265 litros", 650000, 15, true);
        ProductoData pData = new ProductoData();
//         pData.registrarProducto(producto);
//         pData.modificarProducto(producto);
//         pData.eliminarProducto(0);


//         DetalleVenta detVenta=new DetalleVenta(3,venta,0,producto);
//         DetalleVentaData dvData=new DetalleVentaData();
////         dvData.cargarDetalleVenta(detVenta);
//
//
//        String fecha = "2023-08-25";
//        LocalDate fechaVent = LocalDate.parse(fecha);
//        for (Producto aux : dvData.listarProductoXfecha(fechaVent)) {
//            System.out.println(aux.toString());
        }


//        
//pData.eliminarProducto(1);
//pData.modificarProducto(producto);
    }
    

